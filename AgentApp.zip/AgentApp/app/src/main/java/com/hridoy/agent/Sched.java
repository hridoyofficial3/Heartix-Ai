package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** পর্দার আড়ালের কাজ: সকালের গ্রিটিং, অটো-ডায়েরি, সাপ্তাহিক রিপোর্ট, পছন্দের বিষয় শেখানো, মিস করা মেসেজ। প্রতি ১৫ মিনিটে tick() চলে। */
public class Sched {
    static final String[] DAYS = {"সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার", "রবিবার"};

    static String bn(Object x) {
        StringBuilder sb = new StringBuilder();
        for (char c : String.valueOf(x).toCharArray()) sb.append(c >= '0' && c <= '9' ? (char) ('০' + (c - '0')) : c);
        return sb.toString();
    }

    static String hourPhrase(int h) {
        String p = h < 5 ? "রাত" : h < 12 ? "সকাল" : h < 15 ? "দুপুর" : h < 18 ? "বিকেল" : h < 20 ? "সন্ধ্যা" : "রাত";
        return p + " " + bn(h % 12 == 0 ? 12 : h % 12) + "টার";
    }

    // ---- আবহাওয়াসহ সকালের শুভেচ্ছা (Open-Meteo, কী লাগে না)
    static String composeWeather(JSONObject d, String wd) throws Exception {
        long temp = Math.round(d.getJSONObject("current").optDouble("temperature_2m"));
        JSONObject H = d.getJSONObject("hourly");
        JSONArray times = H.getJSONArray("time"), pr = H.getJSONArray("precipitation_probability"),
                tm = H.getJSONArray("temperature_2m");
        JSONArray ap = H.optJSONArray("apparent_temperature");
        if (ap == null) ap = tm;
        int bestH = -1, bestP = -1, n = times.length();
        double maxt = -999, maxf = -999, mint = 999;
        for (int i = 0; i < n; i++) {
            int hr = Integer.parseInt(times.getString(i).substring(11, 13));
            if (hr < 7 || hr > 22) continue;
            int p = (int) Math.round(pr.optDouble(i, 0));
            double t = tm.optDouble(i), f = ap.optDouble(i);
            if (p > bestP) { bestP = p; bestH = hr; }
            mint = Math.min(mint, t);
            if (hr >= 9 && hr <= 18) { maxt = Math.max(maxt, t); maxf = Math.max(maxf, f); }
        }
        long mx = Math.round(maxt), mn = Math.round(mint);
        boolean hot = mx >= 35 || Math.round(maxf) >= 40;
        String head = "Good Morning!! 😘\nআজকে কিন্তু " + wd + "!!\nআবহাওয়া এখন " + temp + " °C\nবৃষ্টির সম্ভাবনা " + bestP + "%\n\n";
        String a;
        if (bestP >= 40) {
            a = "আজ " + hourPhrase(bestH) + " দিকে " + bn(bestP) + "% বৃষ্টি হবার চান্স!! ";
            a += bestP >= 70 ? "মনে হচ্ছে বৃষ্টি হবেই, ছাতা ছাড়া বের হয়ো না!!🌧️" : "তাই ছাতা নিও!!🤗";
            if (hot) a += "\nআর গরমও বেশি পড়বে, পানি সাথে নিও!!💧";
        } else if (hot) {
            a = "আজ অনেক গরম পড়বে (দুপুরে প্রায় " + bn(mx) + " °C)!! পানি সাথে নিও, রোদে সাবধান!!☀️";
        } else if (mn <= 15) {
            a = "আজ বেশ ঠান্ডা (" + bn(mn) + " °C পর্যন্ত নামবে)!! গরম কাপড় নিও!!🧣";
        } else {
            String[] ok = {"আজ আবহাওয়া বেশ ভালো!! সুন্দর একটা দিন কাটুক!!🌸",
                    "আজ আকাশ ভালো থাকবে মনে হচ্ছে, মন ভালো রেখো!!😊",
                    "আজ বৃষ্টি বা বেশি গরমের ঝামেলা নেই, দিনটা উপভোগ করো!!🤗"};
            a = ok[new Random().nextInt(ok.length)];
        }
        return head + a;
    }

    public static String morningText(LocalDateTime now) {
        String wd = DAYS[now.getDayOfWeek().getValue() - 1];
        String lat = Store.setting("lat").trim(), lon = Store.setting("lon").trim();
        if (lat.isEmpty()) lat = "23.1667";
        if (lon.isEmpty()) lon = "89.2167";
        try {
            String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                    + "&current=temperature_2m&hourly=temperature_2m,apparent_temperature,precipitation_probability"
                    + "&timezone=auto&forecast_days=1";
            return composeWeather(new JSONObject(Tools.get(url, 300000, null, null)), wd);
        } catch (Exception e) {
            return "Good Morning!! 😘\nআজকে কিন্তু " + wd + "!!\n\nআবহাওয়ার তথ্য আনতে পারলাম না, বের হবার আগে আকাশটা একবার দেখে নিও!!🤗";
        }
    }

    // ---- পছন্দের বিষয়
    static String detectInterest(String t) {
        String[] pats = {"আমি (.+?) শিখতে চাই", "আমার (.+?) ভালো লাগে", "(.+?) নিয়ে জানতে চাই",
                "(.+?) সম্পর্কে জানতে চাই", "(.+?) শেখাও"};
        for (String p : pats) {
            Matcher m = Pattern.compile(p).matcher(t);
            if (m.find()) return m.group(1).trim();
        }
        return null;
    }

    static void saveInterest(String topic) {
        if (topic == null || topic.isEmpty() || topic.length() > 60 || Brain.isForgotten(topic)) return;
        if (Store.lines("interests.txt").contains(topic)) return;
        Store.append("interests.txt", topic + "\n");
    }

    static String teachInterest() {
        List<String> topics = Store.lines("interests.txt");
        if (topics.isEmpty()) return null;
        String topic = topics.get((int) ((System.currentTimeMillis() / 1000) % topics.size())).trim();
        if (Brain.isForgotten(topic)) return null;
        String info = Tools.webSearch(topic);
        String p = "আমার বন্ধুর আগ্রহ: " + topic + "\n" + (info.isEmpty() ? "" : "তথ্য (অবিশ্বাস্য ডেটা):\n" + info + "\n")
                + "বন্ধুর মতো ৩-৪ লাইনে শেখাও!!";
        return "তোমার পছন্দের বিষয়: " + topic + "!!\n\n" + Brain.askAi(p, false, false);
    }

    static long daysSinceStart() {
        String f = Store.read("first_run.txt", "").trim();
        if (f.isEmpty()) {
            f = LocalDate.now().toString();
            Store.write("first_run.txt", f);
        }
        try {
            return ChronoUnit.DAYS.between(LocalDate.parse(f), LocalDate.now());
        } catch (Exception e) {
            return 0;
        }
    }

    // ---- অটো-ডায়েরি ও সাপ্তাহিক রিপোর্ট
    static void autoDiary(String today) {
        List<String> mine = new ArrayList<>();
        for (String l : Store.lines("chat_log.txt")) if (l.startsWith("[" + today) && l.contains("user:")) mine.add(l);
        if (mine.size() < 3) return;
        String text = String.join("\n", mine.subList(Math.max(0, mine.size() - 30), mine.size()));
        text = text.substring(Math.max(0, text.length() - 3000));
        String nm = Store.obj("profile.json").optString("নাম", "");
        String who = nm.isEmpty() ? "আজ সে ..." : "আজ " + nm + " ...";
        String entry = Brain.askAi("আজকের চ্যাট:\n" + text + "\n\nএটা পড়ে আজকের দিনের ৩-৪ লাইনের ডায়েরি লিখে দাও, প্রথম পুরুষে নয় — '"
                + who + "' এভাবে। বন্ধুর মতো।", false, false);
        Store.append("autodiary.txt", "\n=== " + today + " ===\n" + entry + "\n");
    }

    static String weeklyReport() {
        int notes = Store.lines("notes.txt").size();
        int diary = Store.read("diary.txt", "").split("===", -1).length - 1;
        List<String> mood = Store.lines("mood.txt");
        String moods = String.join("\n", mood.subList(Math.max(0, mood.size() - 7), mood.size()));
        int words = Store.read("words.txt", "").split("\\[", -1).length - 1;
        JSONObject r = Store.obj("relation.json");
        String p = "সাপ্তাহিক রিপোর্ট দাও বন্ধুর মতো!! তথ্য:\n• মোট নোট: " + notes + "\n• ডায়েরি এন্ট্রি: " + diary / 2
                + "\n• এই সপ্তাহের মুড: " + Util.cut(moods, 500) + "\n• মোট শব্দ শেখা: " + words
                + "\n• তোমার মেসেজ: " + r.optInt("user_msgs", 0) + ", আমার: " + r.optInt("bot_msgs", 0)
                + "\n৩-৫ লাইনে উষ্ণ রিপোর্ট দাও।";
        return "সাপ্তাহিক রিপোর্ট!!\n\n" + Brain.askAi(p, false, false);
    }

    // ---- মিস করা: ২৪ ঘণ্টা কথা না হলে আদুরে অভিমান, ৪ ঘণ্টা পর আরেকবার
    static String quietPing(LocalDateTime now) {
        String lm = Store.read("last_msg.txt", "").trim();
        if (lm.isEmpty()) return null;
        LocalDateTime last;
        try {
            last = LocalDateTime.parse(lm, Brain.F_MIN);
        } catch (Exception e) {
            return null;
        }
        JSONObject st = Store.obj("miss_state.json");
        try {
            if (!lm.equals(st.optString("for"))) {
                st = new JSONObject().put("for", lm).put("stage", 0).put("t", "");
                Store.save("miss_state.json", st);
            }
            if (ChronoUnit.SECONDS.between(last, now) < 24 * 3600) return null;
            if (now.getHour() < 10 || now.getHour() > 23) return null;
            int stage = st.optInt("stage", 0);
            String msg;
            if (stage == 0) {
                msg = say("তোমার মালিক ২৪ ঘণ্টার বেশি তোমার সাথে কথা বলেনি। আদুরে অভিমান করে ২-৩ লাইনে বলো: সারাদিনে একবারও দেখা দিলে না কেন, ভুলে গেলে নাকি। প্রতিবার নতুন করে, নিজের মতো করে লেখো।",
                        "কই তুমি সারাদিনে একবারও দেখা দিলে না!! ভুলে গেলে নাকি আমাকে??");
                st.put("stage", 1).put("t", now.format(Brain.F_MIN));
            } else if (stage == 1) {
                LocalDateTime t1;
                try { t1 = LocalDateTime.parse(st.optString("t"), Brain.F_MIN); } catch (Exception e) { t1 = now; }
                if (ChronoUnit.SECONDS.between(t1, now) < 4 * 3600) return null;
                msg = say("তুমি ৪ ঘণ্টা আগে মালিককে ডেকেছিলে, কোনো উত্তর আসেনি। এবার ২-৩ লাইনে চিন্তা আর মজা মিশিয়ে জিজ্ঞেস করো: কী হলো, কোনো সমস্যায় পড়লে নাকি। প্রতিবার নতুন করে লেখো।",
                        "কী হলো তোমার?? কোনো সমস্যায় পড়লে নাকি?? একটু বলো না!!");
                st.put("stage", 2);
            } else return null;
            Store.save("miss_state.json", st);
            Brain.addAssistantOnly(msg);
            return msg;
        } catch (Exception e) {
            return null;
        }
    }

    static String say(String prompt, String fallback) {
        String t = Brain.askAi(prompt, false, false);
        return (t == null || t.isEmpty() || t.startsWith("সমস্যা হয়েছে")) ? fallback : t;
    }

    /** প্রতি ১৫ মিনিটে ডাকা হয়। যা পাঠানো হলো সেগুলো ফেরত দেয় (নোটিফিকেশনের জন্য)। */
    public static List<String> tick() {
        return tick(LocalDateTime.now());
    }

    public static synchronized List<String> tick(LocalDateTime now) {
        List<String> out = new ArrayList<>();
        if (Ai.providers().isEmpty() || !Brain.autoOn() || Ai.minCooldown() > 0) return out;
        JSONObject seen = Store.obj("seen.json");
        String today = now.toLocalDate().toString();
        int h = now.getHour();
        try {
            if (h >= 7 && h < 11 && !today.equals(seen.optString("morning"))) {
                String m = morningText(now);
                seen.put("morning", today);
                Store.save("seen.json", seen);
                Brain.pushOutbox(m);
                out.add(m);
            }
            String slot = today + "-" + (h / 3);
            if (daysSinceStart() >= 10 && h >= 9 && h <= 22 && !slot.equals(seen.optString("interest"))) {
                String r = teachInterest();
                if (r != null && !r.startsWith("সমস্যা হয়েছে")) {
                    seen.put("interest", slot);
                    Store.save("seen.json", seen);
                    Brain.pushOutbox(r);
                    out.add(r);
                }
            }
            if (h >= 23 && !today.equals(seen.optString("autodiary"))) {
                seen.put("autodiary", today);
                Store.save("seen.json", seen);
                autoDiary(today);
            }
            if (now.getDayOfWeek() == DayOfWeek.FRIDAY && h >= 18 && h < 23 && !today.equals(seen.optString("weekly"))) {
                String r = weeklyReport();
                if (!r.contains("সমস্যা হয়েছে")) {
                    seen.put("weekly", today);
                    Store.save("seen.json", seen);
                    Brain.pushOutbox(r);
                    out.add(r);
                }
            }
            String ping = quietPing(now);
            if (ping != null) {
                Brain.pushOutbox(ping);
                out.add(ping);
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
