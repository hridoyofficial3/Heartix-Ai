package com.hridoy.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** ফোন রিস্টার্ট হলে রিমাইন্ডারের অ্যালার্ম আবার বসায়। */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        Boot.init(ctx);
        Brain.rescheduleAll();
    }
}
