package com.hridoy.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        Boot.init(ctx);
        String id = intent.getStringExtra("id");
        String text = intent.getStringExtra("text");
        if (id == null || text == null) return;
        if (Brain.claim(id)) {
            Chats.push("bot", "রিমাইন্ডার!!\n\n" + text);
            Alarms.notify(ctx, text);
        }
    }
}
