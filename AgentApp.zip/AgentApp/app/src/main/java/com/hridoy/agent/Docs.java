package com.hridoy.agent;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** কোড ফাইল/জিপ রিভিউ ও 'জিপ বানাও' (ঠিক করা জিপ তৈরি)। */
public class Docs {
    static final String[] EXTS = {".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".php", ".html",
            ".css", ".json", ".md", ".txt", ".sh", ".yml", ".yaml", ".toml", ".kt", ".rb", ".xml", ".gradle"};
    static final int MAX_CODE = 8000, MAX_OUT = 2500;
    static final Pattern FIX_RE = Pattern.compile("ঠিক|ফিক্স|fix|বানাও|সারাও|সমাধান|আপডেট");
    static final Pattern FILE_RE = Pattern.compile("<<<FILE (.+?)>>>\\n(.*?)\\n<<<END>>>", Pattern.DOTALL);

    public static final class OutFile {
        public final String name;
        public final byte[] data;

        OutFile(String name, byte[] data) {
            this.name = name;
            this.data = data;
        }
    }

    static byte[] zip;
    static String zipName = "";
    public static volatile OutFile out;

    static synchronized void ensure() {
        if (zip == null) {
            zip = Store.readBytes("last.zip");
            zipName = Store.read("last.name", "");
        }
    }

    public static synchronized boolean hasZip() {
        ensure();
        return zip != null && zip.length > 0;
    }

    public static boolean wantsFix(String t) {
        String low = t.toLowerCase();
        return hasZip() && (t.contains("জিপ") || low.contains("zip")) && FIX_RE.matcher(low).find();
    }

    static byte[] singleZip(String name, byte[] data) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bo, StandardCharsets.UTF_8)) {
            z.putNextEntry(new ZipEntry(name));
            z.write(data);
            z.closeEntry();
        }
        return bo.toByteArray();
    }

    public static boolean isCode(String fn) {
        String l = fn.toLowerCase();
        for (String e : EXTS) if (l.endsWith(e)) return true;
        return false;
    }

    /** ফেরত: কোডের লেখা; skipped-এ বাদ পড়া ফাইলের নাম। */
    static String collect(byte[] data, List<String> skipped) throws Exception {
        StringBuilder sb = new StringBuilder();
        int total = 0;
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data), StandardCharsets.UTF_8)) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String fn = e.getName();
                if (e.isDirectory() || !isCode(fn)) continue;
                if (fn.contains("node_modules/") || fn.contains(".git/")) continue;
                byte[] b = Util.readAll(z, 100001);
                if (b.length > 100000) { skipped.add(fn); continue; }
                String t = new String(b, StandardCharsets.UTF_8);
                if (total + t.length() > MAX_CODE) { skipped.add(fn); continue; }
                if (sb.length() > 0) sb.append("\n\n");
                sb.append("=== ").append(fn).append(" ===\n").append(t);
                total += t.length();
            }
        }
        return sb.toString();
    }

    /** ফাইল/জিপ পাওয়ার পর রিভিউ। */
    public static String review(String name, byte[] data, String caption) {
        try {
            boolean isZip = name.toLowerCase().endsWith(".zip");
            synchronized (Docs.class) {
                if (isZip) { zip = data; zipName = name; }
                else { zip = singleZip(name, data); zipName = name + ".zip"; }
                Store.writeBytes("last.zip", zip);
                Store.write("last.name", zipName);
            }
            List<String> skipped = new ArrayList<>();
            String code = collect(zip, skipped);
            if (code.trim().isEmpty()) return isZip ? "কোড পাওয়া যায়নি (বা এটা সঠিক zip না)।" : "কোড পাওয়া যায়নি।";
            String instr = (caption == null || caption.trim().isEmpty())
                    ? "এই কোড রিভিউ করো। কী করে, বাগ আছে কি, কীভাবে ভালো করা যায় — বাংলায় সংক্ষেপে বলো." : caption;
            org.json.JSONArray msgs = new org.json.JSONArray()
                    .put(Ai.msg("system", Brain.sp())).put(Ai.msg("user", instr + "\n\n" + code));
            String reply = Ai.call(msgs, MAX_OUT);
            if (!skipped.isEmpty()) reply += "\n\n(বাদ: " + String.join(", ", skipped.subList(0, Math.min(10, skipped.size()))) + ")";
            reply += "\n\nঠিক করা জিপ চাইলে: জিপ বানাও";
            Brain.addExchange("[ফাইল: " + name + "]", reply);
            return reply;
        } catch (Exception e) {
            return "সমস্যা: " + Brain.safeErr(e);
        }
    }

    /** 'জিপ বানাও' — AI ফাইল বদলায়, নতুন জিপ তৈরি হয় (out-এ থাকে, UI সেভ করতে দেয়)। */
    public static String fix(String text) {
        try {
            ensure();
            List<String> skipped = new ArrayList<>();
            String code = collect(zip, skipped);
            String task = text + "\n\nকোডের সমস্যা ঠিক করো। ফরম্যাট:\n<<<FILE path>>>\n(কনটেন্ট)\n<<<END>>>\nশেষে ২-৩ লাইনে সারসংক্ষেপ।\n\n" + code;
            org.json.JSONArray msgs = new org.json.JSONArray()
                    .put(Ai.msg("system", Brain.sp())).put(Ai.msg("user", task));
            String reply = Ai.call(msgs, MAX_OUT);
            Matcher m = FILE_RE.matcher(reply);
            Map<String, String> changes = new LinkedHashMap<>();
            while (m.find()) {
                String p = m.group(1).trim();
                if (!p.isEmpty() && !p.startsWith("/") && !p.contains("..")) changes.put(p, m.group(2));
            }
            String summary = FILE_RE.matcher(reply).replaceAll("").trim();
            if (changes.isEmpty()) return reply.isEmpty() ? "কিছু বদলাতে হবে না।" : reply;
            List<String> names = new ArrayList<>(changes.keySet());
            Map<String, String> left = new LinkedHashMap<>(changes);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(zip), StandardCharsets.UTF_8);
                 ZipOutputStream zout = new ZipOutputStream(bo, StandardCharsets.UTF_8)) {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    String fn = e.getName();
                    zout.putNextEntry(new ZipEntry(fn));
                    if (!e.isDirectory()) {
                        byte[] b = Util.readAll(zin, 60_000_000);
                        if (left.containsKey(fn)) b = left.remove(fn).getBytes(StandardCharsets.UTF_8);
                        zout.write(b);
                    }
                    zout.closeEntry();
                }
                for (Map.Entry<String, String> en : left.entrySet()) {
                    zout.putNextEntry(new ZipEntry(en.getKey()));
                    zout.write(en.getValue().getBytes(StandardCharsets.UTF_8));
                    zout.closeEntry();
                }
            }
            byte[] nz = bo.toByteArray();
            String on = zipName.startsWith("fixed_") ? zipName : "fixed_" + zipName;
            synchronized (Docs.class) {
                zip = nz;
                zipName = on;
                Store.writeBytes("last.zip", nz);
                Store.write("last.name", on);
            }
            out = new OutFile(on, nz);
            return (summary.isEmpty() ? "হয়ে গেছে!!" : summary) + "\n\nবদলানো: " + String.join(", ", names)
                    + "\n\nনিচের বোতামে চাপ দিয়ে জিপটা সেভ করো।";
        } catch (Exception e) {
            return "সমস্যা: " + Brain.safeErr(e);
        }
    }

    public static OutFile takeOut() {
        OutFile o = out;
        out = null;
        return o;
    }

    public static String status() {
        ensure();
        return zipName.isEmpty() ? "নেই" : zipName;
    }
}
