package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.net.URLDecoder;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** WebView UI (assets/index.html)-র পেছনের "সার্ভার": একই /api/... পথ, কিন্তু ফোনের ভেতরেই, নেটওয়ার্ক ছাড়া। */
public class Api {
    /** অ্যান্ড্রয়েডের দিকের কাজ — MainActivity বসায়। */
    public interface Env {
        void pick(String purpose);
        void quit();
        void notifyUser(String title, String text);
        String saveDownload(String name, byte[] data);
        String download(String url, boolean audio);
        void bars(String theme);
    }

    public static volatile Env env;
    static final ExecutorService chatExec = Executors.newSingleThreadExecutor();
    static ScheduledExecutorService ticker;

    // ---- অ্যাপ চালুর সময় একবার
    public static synchronized void start() {
        Chats.init();
        if (ticker != null) return;
        drain(false);
        ticker = Executors.newSingleThreadScheduledExecutor();
        ticker.scheduleWithFixedDelay(() -> {
            try { drain(true); } catch (Throwable ignored) { }
        }, 15, 15, TimeUnit.SECONDS);
    }

    /** সময় হওয়া রিমাইন্ডার ও ব্যাকগ্রাউন্ডে আসা বার্তা চ্যাটে বসায়। */
    static void drain(boolean notifyIfAway) {
        for (String t : Brain.dueReminders()) botPush("রিমাইন্ডার!!\n\n" + t, notifyIfAway);
        for (String t : Brain.takeOutbox()) botPush(t, false);   // ব্যাকগ্রাউন্ড ওয়ার্কার আগেই নোটিফিকেশন দিয়েছে
    }

    static void botPush(String text, boolean notifyIfAway) {
        Chats.push("bot", text);
        Env e = env;
        if (notifyIfAway && e != null && System.currentTimeMillis() - Chats.seen > 12000) e.notifyUser(Brain.charName(), text);
    }

    // ---- /api/... রাউটার
    static Map<String, String> query(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null) return m;
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            try {
                m.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            } catch (Exception ignored) {
            }
        }
        return m;
    }

    static long lng(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return 0; }
    }

    /** body খালি = GET, নইলে POST। ফেরত: JSON লেখা। */
    public static String handle(String path, String body) throws Exception {
        String route = path, qs = "";
        int qi = path.indexOf('?');
        if (qi >= 0) { route = path.substring(0, qi); qs = path.substring(qi + 1); }
        Map<String, String> q = query(qs);
        boolean post = body != null && !body.isEmpty();
        JSONObject d = post ? new JSONObject(body) : new JSONObject();
        Env e = env;
        switch (route) {
            case "/api/avatar":
                return avatar().toString();
            case "/api/messages":
                Chats.seen = System.currentTimeMillis();
                return Chats.since((int) lng(q.get("after")), lng(q.get("sid"))).toString();
            case "/api/sessions": {
                if (!post) return Chats.sessions(q.get("q")).toString();
                String a = d.optString("action");
                if (a.equals("new")) Chats.newSession();
                else if (a.equals("open")) Chats.open(d.optLong("id"));
                else if (a.equals("delete")) Chats.delete(d.optLong("id"));
                else if (a.equals("rename")) Chats.rename(d.optLong("id"), d.optString("title"));
                return new JSONObject().put("ok", true).toString();
            }
            case "/api/settings": {
                if (!post) return Brain.settings().toString();
                JSONObject s = Brain.saveSettings(d);
                if (e != null) e.bars(s.optString("theme"));
                return s.toString();
            }
            case "/api/keys":
                return (post ? Keys.action(d) : Keys.list()).toString();
            case "/api/send":
                return sendUser(d.optString("text")).toString();
            case "/api/pick":
                if (e != null) e.pick(d.optString("purpose", "file"));
                return new JSONObject().put("ok", true).toString();
            case "/api/quit":
                if (e != null) e.quit();
                return new JSONObject().put("ok", true).toString();
            case "/api/avatar_set":
                return avatarSet(d.optString("data")).toString();
            case "/api/avatar_clear":
                new File(Store.dir, "avatar.jpg").delete();
                return new JSONObject().put("ok", true).toString();
            case "/api/clear":
                Chats.delete(Chats.active());
                return new JSONObject().put("ok", true).toString();
            default:
                throw new Exception("not found");
        }
    }

    // ---- বার্তা পাঠানো
    public static JSONObject sendUser(String text) throws Exception {
        text = Util.cut(text == null ? "" : text.trim(), 4000);
        if (text.isEmpty()) return new JSONObject().put("msg", JSONObject.NULL);
        final long sid = Chats.active();
        JSONObject m = Chats.push("user", text, sid);
        final String t = text;
        chatExec.execute(() -> run(sid, () -> reply(t)));
        return new JSONObject().put("msg", m);
    }

    interface Job {
        String go() throws Exception;
    }

    static void run(long sid, Job job) {
        Chats.typing = true;
        Chats.typingSid = sid;
        try {
            String r = job.go();
            if (r != null && !r.trim().isEmpty()) Chats.push("bot", r, sid);
            Docs.OutFile f = Docs.takeOut();
            if (f != null) {
                Env e = env;
                String where = e == null ? null : e.saveDownload(f.name, f.data);
                Chats.push("bot", where == null ? "জিপ বানানো হয়েছে, কিন্তু সেভ করা গেল না।" : "জিপ সেভ হয়েছে: " + where, sid);
            }
        } catch (Throwable ex) {
            Chats.push("bot", "সমস্যা: " + Brain.safeErr(ex instanceof Exception ? (Exception) ex : new Exception(ex)), sid);
        } finally {
            Chats.typing = false;
        }
    }

    /** লিংক/ডাউনলোড/সাধারণ চ্যাট — কোন পথে যাবে ঠিক করে। */
    static String reply(String t) throws Exception {
        if (Links.urlOnly(t) != null)
            return "লিংকটা পেলাম!! কী করব? লেখো: 'ডাউনলোড' (ভিডিও/ফাইল নামাব), 'অডিও' (শুধু অডিও), অথবা 'কিসের লিংক' (খুলে দেখব কী আছে)।";
        String dl = Links.downloadUrl(t);
        Env e = env;
        if (dl != null && e != null) return e.download(dl, Links.wantsAudio(t));
        String iu = Links.infoUrl(t);
        if (iu != null) return Links.infoReply(iu, t);
        return Brain.chat(t);
    }

    // ---- ছবি ও ফাইল
    public static JSONObject sendImage(String name, String b64, String mime) throws Exception {
        final long sid = Chats.active();
        JSONObject m = Chats.push("user", "📎 " + name, sid);
        chatExec.execute(() -> run(sid, () -> {
            if (Ai.providers().isEmpty() && Ai.visionProviders().isEmpty())
                return "আগে সেটিংস → API key ম্যানেজার থেকে একটা API key যোগ করো, তারপর ছবি দেখব!!";
            return Vision.handle("", b64, mime);
        }));
        return new JSONObject().put("ok", true).put("msg", m);
    }

    public static JSONObject sendFile(String name, byte[] data) throws Exception {
        final long sid = Chats.active();
        JSONObject m = Chats.push("user", "📎 " + name, sid);
        chatExec.execute(() -> run(sid, () -> {
            if (data.length > 8_000_000) return "ফাইলটা অনেক বড় (৮MB-র বেশি)। ছোট করে পাঠাও।";
            if (Ai.providers().isEmpty()) return "আগে সেটিংস → API key ম্যানেজার থেকে একটা API key যোগ করো, তারপর ফাইল দেখব!!";
            String n = name.toLowerCase();
            boolean zip = n.endsWith(".zip");
            boolean text = Docs.isCode(n) || !hasNul(data);
            if (n.endsWith(".pdf")) return "PDF পড়ার অংশ এই অ্যাপে এখনো নেই। লেখা কপি করে পাঠাও।";
            if (!zip && !text) return "এই ধরনের ফাইল পড়তে পারি না। ছবি, zip বা লেখার/কোডের ফাইল পাঠাও।";
            return Docs.review(name, data, "");
        }));
        return new JSONObject().put("ok", true).put("msg", m);
    }

    static boolean hasNul(byte[] b) {
        for (int i = 0; i < Math.min(b.length, 2000); i++) if (b[i] == 0) return true;
        return false;
    }

    // ---- প্রোফাইল ছবি
    static File avatarFile() {
        return new File(Store.dir, "avatar.jpg");
    }

    public static JSONObject avatar() throws Exception {
        File f = avatarFile();
        if (!f.exists()) return new JSONObject().put("v", 0).put("u", "");
        byte[] raw = Store.readBytes("avatar.jpg");
        return new JSONObject().put("v", (int) (f.lastModified() / 1000))
                .put("u", "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(raw));
    }

    public static JSONObject avatarSet(String data) throws Exception {
        byte[] raw;
        try {
            String b = data.contains(",") ? data.substring(data.indexOf(',') + 1) : data;
            raw = Base64.getDecoder().decode(b.trim());
        } catch (Exception e) {
            return new JSONObject().put("ok", false).put("err", "ছবি পড়া যায়নি");
        }
        return avatarSetBytes(raw);
    }

    public static JSONObject avatarSetBytes(byte[] raw) throws Exception {
        if (raw.length < 3 || (raw[0] & 0xFF) != 0xFF || (raw[1] & 0xFF) != 0xD8 || raw.length > 200000)
            return new JSONObject().put("ok", false).put("err", "ছবি ঠিক নেই বা বড়");
        Store.writeBytes("avatar.jpg", raw);
        return new JSONObject().put("ok", true);
    }
}
