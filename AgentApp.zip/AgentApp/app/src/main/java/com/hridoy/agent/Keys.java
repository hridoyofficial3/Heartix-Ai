package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** API key ম্যানেজার: যত ইচ্ছে key (নাম + মডেল + ঠিকানা), ওপরেরটা ডিফল্ট ও সেরা। */
public class Keys {
    public static final int MAX = 50;
    static final Map<String, String[]> PROV = new LinkedHashMap<>();

    static {
        PROV.put("groq", new String[]{"https://api.groq.com/openai/v1/chat/completions", "openai/gpt-oss-120b"});
        PROV.put("gemini", new String[]{"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-flash-latest"});
        PROV.put("mistral", new String[]{"https://api.mistral.ai/v1/chat/completions", "mistral-large-latest"});
        PROV.put("openrouter", new String[]{"https://openrouter.ai/api/v1/chat/completions", "openai/gpt-oss-120b:free"});
        PROV.put("openai", new String[]{"https://api.openai.com/v1/chat/completions", "gpt-4o-mini"});
        PROV.put("deepseek", new String[]{"https://api.deepseek.com/chat/completions", "deepseek-chat"});
        PROV.put("custom", new String[]{"", ""});
    }

    static String cap(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    static void norm(JSONObject k) throws Exception {
        String p = k.optString("provider", "custom");
        if (p.isEmpty()) p = "custom";
        k.put("provider", p);
        if (PROV.containsKey(p) && !p.equals("custom")) {
            if (!k.has("url")) k.put("url", PROV.get(p)[0]);
            if (!k.has("model")) k.put("model", PROV.get(p)[1]);
        }
        if (!k.has("name")) k.put("name", cap(p));
        if (!k.has("search")) k.put("search", false);
        if (!k.has("enabled")) k.put("enabled", true);
    }

    public static synchronized List<JSONObject> all() {
        JSONArray a = Store.arr("keys.json");
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject k = a.optJSONObject(i);
            if (k == null) continue;
            try { norm(k); out.add(k); } catch (Exception ignored) { }
        }
        return out;
    }

    static void saveAll(List<JSONObject> ks) {
        JSONArray a = new JSONArray();
        for (JSONObject k : ks) a.put(k);
        Store.save("keys.json", a);
    }

    public static List<String> secrets() {
        List<String> out = new ArrayList<>();
        for (JSONObject k : all()) if (!k.optString("key").isEmpty()) out.add(k.optString("key"));
        return out;
    }

    static String mask(String k) {
        return k.length() > 10 ? k.substring(0, 4) + "…" + k.substring(k.length() - 4) : "…";
    }

    public static JSONObject list() throws Exception {
        JSONArray out = new JSONArray();
        Long act = null;
        for (JSONObject k : all()) {
            int cd = Ai.cooldown(k.optString("name"), k.optString("model"), k.optString("key"));
            long id = k.optLong("id");
            if (act == null && k.optBoolean("enabled", true) && cd == 0) act = id;
            out.put(new JSONObject().put("id", id).put("provider", k.optString("provider")).put("name", k.optString("name"))
                    .put("model", k.optString("model")).put("masked", mask(k.optString("key")))
                    .put("enabled", k.optBoolean("enabled", true)).put("search", k.optBoolean("search", false))
                    .put("cooldown", cd));
        }
        for (int i = 0; i < out.length(); i++) {
            JSONObject o = out.getJSONObject(i);
            o.put("active", act != null && o.optLong("id") == act);
        }
        return new JSONObject().put("keys", out).put("max", MAX);
    }

    static JSONObject res(boolean ok, String msgKey, String msg) throws Exception {
        return new JSONObject().put("ok", ok).put(msgKey, msg);
    }

    public static synchronized JSONObject action(JSONObject d) throws Exception {
        String a = d.optString("action");
        List<JSONObject> ks = all();
        long kid = d.optLong("id");
        if (a.equals("add")) {
            String p = d.optString("provider", "custom");
            if (p.isEmpty()) p = "custom";
            String k = d.optString("key", "").trim();
            if (!PROV.containsKey(p)) return res(false, "err", "সার্ভিস বেছে নাও");
            String url = p.equals("custom") ? d.optString("url", "").trim() : PROV.get(p)[0];
            String model = Util.cut(d.optString("model", "").trim(), 80);
            if (model.isEmpty()) model = PROV.get(p)[1];
            String name = Util.cut(d.optString("name", "").trim(), 30);
            if (name.isEmpty()) name = p.equals("custom") ? Util.cut(model, 30) : cap(p);
            if (!(url.startsWith("https://") || url.startsWith("http://"))) return res(false, "err", "API ঠিকানা দাও (https:// দিয়ে শুরু)");
            String u2 = url.replaceAll("/+$", "");
            if (!u2.endsWith("/chat/completions")) url = u2 + "/chat/completions";
            if (model.isEmpty()) return res(false, "err", "মডেলের নাম লেখো");
            if (k.length() < 8 || k.matches("(?s).*\\s.*")) return res(false, "err", "key ঠিক নেই — পুরোটা কপি করেছ?");
            if (ks.size() >= MAX) return res(false, "err", "সর্বোচ্চ " + MAX + "টা রাখা যায়");
            for (JSONObject x : ks) {
                if (x.optString("key").equals(k) && x.optString("model").equals(model) && x.optString("url").equals(url))
                    return res(false, "err", "এই key আর মডেল আগেই যোগ করা আছে");
            }
            ks.add(new JSONObject().put("id", System.currentTimeMillis()).put("provider", p).put("name", name).put("url", url)
                    .put("model", model).put("key", k).put("enabled", true).put("search", d.optBoolean("search", false)));
        } else if (a.equals("edit")) {
            for (JSONObject x : ks) {
                if (x.optLong("id") == kid) {
                    if (!d.optString("name", "").trim().isEmpty()) x.put("name", Util.cut(d.optString("name").trim(), 30));
                    if (!d.optString("model", "").trim().isEmpty()) x.put("model", Util.cut(d.optString("model").trim(), 80));
                    x.put("search", d.optBoolean("search", false));
                }
            }
        } else if (a.equals("delete")) {
            List<JSONObject> keep = new ArrayList<>();
            for (JSONObject x : ks) if (x.optLong("id") != kid) keep.add(x);
            ks = keep;
        } else if (a.equals("toggle") || a.equals("search")) {
            String f = a.equals("toggle") ? "enabled" : "search";
            for (JSONObject x : ks) if (x.optLong("id") == kid) x.put(f, !x.optBoolean(f, f.equals("enabled")));
        } else if (a.equals("default")) {
            int i = idxOf(ks, kid);
            if (i >= 0) ks.add(0, ks.remove(i));
        } else if (a.equals("move")) {
            int i = idxOf(ks, kid);
            if (i >= 0) {
                int j = i + ("up".equals(d.optString("dir")) ? -1 : 1);
                if (j >= 0 && j < ks.size()) {
                    JSONObject t = ks.get(i);
                    ks.set(i, ks.get(j));
                    ks.set(j, t);
                }
            }
        } else if (a.equals("unblock")) {
            Ai.blocked.clear();
        } else if (a.equals("test")) {
            for (JSONObject x : ks) if (x.optLong("id") == kid) return test(x);
            return res(false, "err", "পাওয়া যায়নি");
        }
        saveAll(ks);
        return new JSONObject().put("ok", true);
    }

    static int idxOf(List<JSONObject> ks, long id) {
        for (int i = 0; i < ks.size(); i++) if (ks.get(i).optLong("id") == id) return i;
        return -1;
    }

    static JSONObject test(JSONObject k) throws Exception {
        Ai.Resp r;
        try {
            JSONObject body = new JSONObject().put("model", k.optString("model")).put("max_tokens", 16)
                    .put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", "hi")));
            r = Ai.transport.send(k.optString("url"), k.optString("key"), body.toString());
        } catch (Exception e) {
            return res(false, "err", "নেট নেই বা সার্ভার সাড়া দিচ্ছে না");
        }
        int c = r.code;
        if (c == 200) return res(true, "msg", "ঠিক আছে, কাজ করছে");
        if (c == 401 || c == 403) return res(false, "err", "key ভুল বা অনুমতি নেই");
        if (c == 429) return res(true, "msg", "key ঠিক আছে, তবে এখন লিমিট শেষ");
        if (c == 402) return res(false, "err", "ক্রেডিট শেষ");
        if (c == 404) return res(false, "err", "মডেলের নাম বা ঠিকানা ভুল (404)");
        return res(false, "err", "সমস্যা (কোড " + c + ")");
    }
}
