package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

/** ছবি দেখে উত্তর। ছবি পাঠানোর পর ১০ মিনিট পর্যন্ত 'ছবিটা/এটা' বলে প্রশ্ন করলে একই ছবি ব্যবহার হয়। */
public class Vision {
    static final String GUIDE = "\n\n[ছবির নিয়ম: ছবিতে যা দেখা যায় সেটাই বলো। মুখ দেখে কাউকে চেনার চেষ্টা করবে না বা নাম বলবে না। "
            + "লেখা থাকলে পড়ে বলো। কোড বা এরর স্ক্রিনশট হলে সমস্যা ও সমাধান বলো। "
            + "আমার ব্যক্তিগত বা আবেগের ছবি হলে বন্ধুর মতো সাড়া দাও। যা স্পষ্ট দেখা যায় না সেটা বানিয়ে বলো না।]";
    static final String DEFAULT_ASK = "আমি এই ছবিটা পাঠিয়েছি। বাংলায় বিস্তারিত বলো: ছবিতে কী কী আছে (মানুষ, প্রাণী, জিনিস), "
            + "রঙ, পরিবেশ, ছবির ভেতরে কোনো লেখা থাকলে সেটা, আর শেষে বন্ধুর মতো একটা ছোট মন্তব্য।";
    // 'ফটোগ্রাফি'-র মতো লম্বা শব্দে ভুল ধরা এড়াতে শব্দের সীমানা দেখা হয়
    static final java.util.regex.Pattern REF = java.util.regex.Pattern.compile(
            "(?<![\\u0980-\\u09FF])(ছবি|ফটো|স্ক্রিন|এটা|ওটা|এইটা|ওইটা|এখানে)(টা|টার|টি|টির|র|কে|তে|গুলো|গুলোর)?(?![\\u0980-\\u09FF])");

    static String lastB64 = null, lastMime = "";
    static long lastT = 0;

    static synchronized void remember(String b64, String mime) {
        lastB64 = b64;
        lastMime = mime;
        lastT = System.currentTimeMillis();
    }

    /** টেক্সটে ছবির উল্লেখ থাকলে সাম্প্রতিক ছবি ফেরত দেয়: {b64, mime}। */
    public static synchronized String[] takeRecent(String text) {
        if (lastB64 == null) return null;
        if (System.currentTimeMillis() - lastT > 600_000) return null;
        if (REF.matcher(text).find()) return new String[]{lastB64, lastMime};
        return null;
    }

    /** UI থেকে ছবি এলে: ক্যাপশন থাকলে সেটাই প্রশ্ন, নইলে ডিফল্ট বিবরণ। */
    public static String handle(String caption, String b64, String mime) {
        caption = caption == null ? "" : caption.trim();
        remember(b64, mime);
        return answer(caption.isEmpty() ? DEFAULT_ASK : caption, caption, b64, mime);
    }

    public static String answer(String ask, String label, String b64, String mime) {
        try {
            JSONArray msgs = new JSONArray();
            msgs.put(Ai.msg("system", Brain.sp()));
            JSONArray mh = Brain.modelHistory(10);
            for (int i = 0; i < mh.length(); i++) msgs.put(mh.get(i));
            JSONArray content = new JSONArray()
                    .put(new JSONObject().put("type", "text").put("text", ask + GUIDE))
                    .put(new JSONObject().put("type", "image_url")
                            .put("image_url", new JSONObject().put("url", "data:" + mime + ";base64," + b64)));
            msgs.put(new JSONObject().put("role", "user").put("content", content));
            String reply = Ai.fixTui(Ai.callVision(msgs));
            Brain.addExchange("[ছবি পাঠিয়েছি" + (label.isEmpty() ? "" : ": " + label) + "]", reply);
            Store.append("chat_log.txt", "[" + Brain.now() + "] user: [ছবি]" + (label.isEmpty() ? "" : " " + label) + "\n");
            Store.append("chat_log.txt", "[" + Brain.now() + "] agent: " + reply + "\n");
            Brain.bump("user");
            Brain.bump("bot");
            Brain.touchLastMsg();
            return reply;
        } catch (Exception e) {
            return "ছবি দেখতে সমস্যা হয়েছে: " + Brain.safeErr(e);
        }
    }
}
