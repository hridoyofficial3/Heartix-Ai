package com.hridoy.agent;

import android.content.Context;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** অ্যাপ বা রিসিভার যেখান থেকেই চালু হোক, একবার সব সেটআপ করে। */
public class Boot {
    private static boolean done = false;

    public static synchronized void init(Context ctx) {
        if (done) return;
        Context app = ctx.getApplicationContext();
        Store.dir = app.getFilesDir();
        try (InputStream is = app.getAssets().open("system_prompt.txt")) {
            Store.promptText = new String(Util.readAll(is, 1_000_000), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
        }
        Brain.init();
        Brain.hook = (ms, id, text) -> Alarms.schedule(app, ms, id, text);
        done = true;
    }
}
