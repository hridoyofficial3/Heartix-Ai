package com.hridoy.agent;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
    public static byte[] readAll(InputStream is, int max) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            if (bo.size() + n > max) {
                bo.write(buf, 0, Math.max(0, max - bo.size()));
                break;
            }
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }

    public static String readAllStr(InputStream is) throws IOException {
        return new String(readAll(is, 4_000_000), StandardCharsets.UTF_8);
    }

    public static String unescape(String s) {
        if (s == null) return "";
        s = s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'");
        Matcher m = Pattern.compile("&#(\\d+);").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep;
            try {
                rep = new String(Character.toChars(Integer.parseInt(m.group(1))));
            } catch (Exception e) {
                rep = "";
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString().replace("&amp;", "&");
    }

    public static String stripTags(String s) {
        return unescape(s.replaceAll("(?s)<.*?>", "")).trim();
    }

    public static String urlDecode(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    public static String cut(String s, int n) {
        return s == null ? "" : (s.length() > n ? s.substring(0, n) : s);
    }
}
