package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** একাধিক AI সার্ভিস ও একাধিক কী: সেরা আগে, লিমিট/এরর হলে পরেরটায়। */
public class Ai {
    static final String GROQ = "https://api.groq.com/openai/v1/chat/completions";
    static final String GEM = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
    static final String MIS = "https://api.mistral.ai/v1/chat/completions";
    static final String OR = "https://openrouter.ai/api/v1/chat/completions";

    public static final class P {
        final String provider, name, url, key, model;

        P(String provider, String name, String url, String key, String model) {
            this.provider = provider; this.name = name; this.url = url; this.key = key; this.model = model;
        }

        String id() {
            return name + "|" + model + "|" + Integer.toHexString(key.hashCode());
        }
    }

    public static final class Resp {
        public int code;
        public String body = "";
        public String retryAfter;
    }

    public interface Transport {
        Resp send(String url, String key, String json) throws Exception;
    }

    public static Transport transport = Ai::http;
    static final Map<String, Long> blocked = new HashMap<>();

    static Resp http(String url, String key, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(30000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        try (OutputStream os = c.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }
        Resp r = new Resp();
        r.code = c.getResponseCode();
        InputStream is = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
        r.body = is == null ? "" : Util.readAllStr(is);
        r.retryAfter = c.getHeaderField("retry-after");
        c.disconnect();
        return r;
    }

    static final ThreadLocal<Boolean> searchMode = new ThreadLocal<>();

    /** API key ম্যানেজারের তালিকার ক্রমে। সার্চ-মোডে 🔎 চিহ্নিতগুলো আগে। */
    public static List<P> providers() {
        List<P> out = new ArrayList<>(), later = new ArrayList<>();
        boolean search = Boolean.TRUE.equals(searchMode.get());
        for (JSONObject k : Keys.all()) {
            if (!k.optBoolean("enabled", true)) continue;
            String url = k.optString("url"), model = k.optString("model"), key = k.optString("key");
            if (url.isEmpty() || model.isEmpty() || key.isEmpty()) continue;
            P p = new P(k.optString("provider"), k.optString("name"), url, key, model);
            if (search && !k.optBoolean("search", false)) later.add(p); else out.add(p);
        }
        out.addAll(later);
        // বিকল্প মডেল: একই key-তে অন্য মডেলের আলাদা লিমিট থাকে — প্রধানগুলো শেষ হলে এগুলোতে যায়
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (P p : out) seen.add(p.key + "|" + p.model);
        List<P> extra = new ArrayList<>();
        for (P p : out) {
            String[] fb = FALLBACK.get(p.provider);
            if (fb == null || !p.url.equals(Keys.PROV.get(p.provider)[0])) continue;
            for (String m : fb) {
                if (seen.add(p.key + "|" + m)) extra.add(new P(p.provider, p.name, p.url, p.key, m));
            }
        }
        out.addAll(extra);
        return out;
    }

    static final Map<String, String[]> FALLBACK = new HashMap<>();

    static {
        FALLBACK.put("groq", new String[]{"llama-3.3-70b-versatile", "openai/gpt-oss-20b", "llama-3.1-8b-instant"});
        FALLBACK.put("gemini", new String[]{"gemini-flash-lite-latest"});
        FALLBACK.put("mistral", new String[]{"mistral-small-latest"});
    }

    /** একটা key-র বাকি অপেক্ষার সময় (সেকেন্ড) */
    public static int cooldown(String name, String model, String key) {
        Long until = blocked.get(name + "|" + model + "|" + Integer.toHexString(key.hashCode()));
        return until == null ? 0 : (int) Math.max(0, (until - System.currentTimeMillis()) / 1000);
    }

    static void block(P p, double secs, String why) {
        blocked.put(p.id(), System.currentTimeMillis() + (long) (secs * 1000));
        System.out.println(why + ": " + p.name + "/" + p.model + " -> " + (int) secs + "s");
    }

    /** লিমিট/এরর হলে বাদ রেখে পরেরটায় যায়; সময় পেরোলে আবার সেরাটায় ফেরে। null = কোনো কী নেই। */
    public static Resp post(JSONObject body, String effort) {
        return post(body, effort, providers());
    }

    public static Resp post(JSONObject body, String effort, List<P> chain) {
        return post0(body, effort, chain, false);
    }

    // ---- লিমিট সামলানো: প্রতি key-তে ন্যূনতম বিরতি, লিমিট-এর সময় বুঝে অপেক্ষা, আর বিকল্প মডেল
    public static long minGapMs = 1500;
    static final Map<String, Long> lastCall = new HashMap<>();

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    /** একই key-তে খুব দ্রুত পরপর অনুরোধ গেলে (RPM লিমিট) একটু থেমে পাঠায়। */
    static void throttle(P p) {
        if (minGapMs <= 0) return;
        String k = Integer.toHexString(p.key.hashCode());
        long wait;
        synchronized (lastCall) {
            long now = System.currentTimeMillis();
            Long l = lastCall.get(k);
            long at = Math.max(now, l == null ? 0 : l + minGapMs);
            lastCall.put(k, at);
            wait = at - now;
        }
        if (wait > 0) sleep(wait);
    }

    static final Pattern HINT = Pattern.compile("try again in ((?:\\d+(?:\\.\\d+)?(?:ms|s|m|h))+)");
    static final Pattern HINT_PART = Pattern.compile("(\\d+(?:\\.\\d+)?)(ms|s|m|h)");
    static final Pattern RETRY_DELAY = Pattern.compile("\"retryDelay\"\\s*:\\s*\"([0-9.]+)s\"");

    /** লিমিট কখন ফিরবে — হেডার/মেসেজ থেকে সেকেন্ডে; না পেলে -1 */
    static double hint(Resp r) {
        try {
            if (r.retryAfter != null) return Double.parseDouble(r.retryAfter.trim());
        } catch (Exception ignored) {
        }
        String b = r.body == null ? "" : r.body;
        Matcher m = HINT.matcher(b);
        if (m.find()) {
            double tot = 0;
            Matcher q = HINT_PART.matcher(m.group(1));
            while (q.find()) {
                double v = Double.parseDouble(q.group(1));
                String u = q.group(2);
                tot += u.equals("ms") ? v / 1000 : u.equals("s") ? v : u.equals("m") ? v * 60 : v * 3600;
            }
            return tot;
        }
        m = RETRY_DELAY.matcher(b);
        return m.find() ? Double.parseDouble(m.group(1)) : -1;
    }

    static boolean daily(Resp r) {
        String b = r.body == null ? "" : r.body.toLowerCase();
        return b.contains("per day") || b.contains("perday") || b.contains("daily");
    }

    static void blockKey(List<P> chain, String key, double secs, String why) {
        for (P x : chain) if (x.key.equals(key)) blocked.put(x.id(), System.currentTimeMillis() + (long) (secs * 1000));
        System.out.println(why + ": key … -> " + (int) secs + "s");
    }

    static long minRemainingMs(List<P> chain) {
        long now = System.currentTimeMillis(), best = Long.MAX_VALUE;
        for (P p : chain) {
            Long until = blocked.get(p.id());
            long rem = until == null || until <= now ? 0 : until - now;
            best = Math.min(best, rem);
        }
        return best == Long.MAX_VALUE ? 0 : best;
    }

    /** সব API এখন লিমিটে থাকলে সবচেয়ে কাছের কতক্ষণ পরে ফিরবে (সেকেন্ড); কোনোটা চালু থাকলে ০ */
    public static int minCooldown() {
        List<P> chain = providers();
        if (chain.isEmpty()) return 0;
        return (int) Math.ceil(minRemainingMs(chain) / 1000.0);
    }

    static Resp post0(JSONObject body, String effort, List<P> chain, boolean retried) {
        if (chain.isEmpty()) return null;
        long now = System.currentTimeMillis();
        List<P> avail = new ArrayList<>();
        for (P p : chain) {
            Long until = blocked.get(p.id());
            if (until == null || until <= now) avail.add(p);
        }
        if (avail.isEmpty()) {
            long soon = minRemainingMs(chain);
            if (soon <= 20000 && !retried) {          // একটু অপেক্ষা করলেই চালু হবে — অপেক্ষা করে আবার চেষ্টা
                sleep(soon + 300);
                return post0(body, effort, chain, true);
            }
            Resp r = new Resp();                      // অকারণে বারবার মেরে লিমিট বাড়াবে না
            r.code = 429;
            r.body = "{\"error\":\"সব API এখন লিমিটে\"}";
            r.retryAfter = String.valueOf((long) Math.ceil(soon / 1000.0));
            return r;
        }
        boolean inTools = false;
        JSONArray ms = body.optJSONArray("messages");
        if (ms != null) {
            for (int i = 0; i < ms.length(); i++) {
                JSONObject m = ms.optJSONObject(i);
                if (m != null && ("tool".equals(m.optString("role")) || m.has("tool_calls"))) inTools = true;
            }
        }
        boolean hasTools = body.has("tools");
        Resp best = null, last = null;
        for (P p : avail) {
            Long still = blocked.get(p.id());
            if (still != null && still > System.currentTimeMillis()) continue;   // একই key-র আগের উত্তরে ব্লক হয়ে গেছে
            // Gemini টুল-কলের ইতিহাসে thought_signature চায়, তাই টুল-ফ্লোতে বাদ
            if (p.url.contains("generativelanguage") && inTools) continue;
            throttle(p);
            Resp r;
            try {
                JSONObject b = new JSONObject(body.toString());
                b.put("model", p.model);
                if (p.url.contains("api.groq.com") && p.model.contains("gpt-oss")) b.put("reasoning_effort", effort);
                r = transport.send(p.url, p.key, b.toString());
            } catch (Exception e) {
                block(p, 60, "নেট/টাইমআউট");
                continue;
            }
            last = r;
            int c = r.code;
            if (c == 429) {
                if (best == null) best = r;
                double h = hint(r);
                double wait = h > 0 ? h + 1 : 60;
                if (daily(r)) wait = Math.max(wait, 3600);
                block(p, Math.min(Math.max(wait, 3), 6 * 3600), "লিমিট (429)");
                continue;
            }
            if (c == 400) { block(p, hasTools ? 300 : 60, "400"); continue; }
            if (c == 413) { block(p, 90, "অনুরোধ বড় (413)"); continue; }
            if (c == 404) { block(p, 6 * 3600, "মডেল পাওয়া যায়নি (404)"); continue; }
            if (c == 401 || c == 403) { blockKey(chain, p.key, 6 * 3600, "কী/অনুমতি সমস্যা (" + c + ")"); continue; }
            if (c >= 500) { block(p, 60, "সার্ভার সমস্যা (" + c + ")"); continue; }
            return r;
        }
        if (best != null && !retried) {               // সবাই লিমিটে: ছোট অপেক্ষা হলে একবার অপেক্ষা করে আবার
            long soon = minRemainingMs(chain);
            if (soon <= 20000) {
                sleep(soon + 300);
                return post0(body, effort, chain, true);
            }
        }
        return best != null ? best : last;
    }

    /** ছবি দেখার মডেল (ক্রমানুসারে চেষ্টা করে)। */
    public static List<P> visionProviders() {
        List<P> out = new ArrayList<>();
        for (JSONObject k : Keys.all()) {
            if (!k.optBoolean("enabled", true) || k.optString("key").isEmpty()) continue;
            String pv = k.optString("provider"), url = k.optString("url"), m;
            if (pv.equals("gemini")) m = "gemini-flash-latest";
            else if (pv.equals("mistral")) m = "mistral-small-latest";
            else if (pv.equals("groq")) m = "meta-llama/llama-4-scout-17b-16e-instruct";
            else if (pv.equals("openai")) m = "gpt-4o-mini";
            else continue;
            out.add(new P(pv, k.optString("name"), url, k.optString("key"), m));
            if (pv.equals("gemini")) out.add(new P(pv, k.optString("name"), url, k.optString("key"), "gemini-flash-lite-latest"));
        }
        return out;
    }

    public static String callVision(JSONArray messages) throws Exception {
        JSONObject body = new JSONObject();
        body.put("messages", messages);
        body.put("temperature", 0.5);
        body.put("max_tokens", 2500);
        Resp r = post(body, "low", visionProviders());
        if (r == null) throw new Exception("ছবি দেখার জন্য Gemini, Mistral বা Groq-এর কী লাগবে");
        if (r.code != 200) throw new Exception("ভিশন মডেল কাজ করছে না (কোড " + r.code + ")। Gemini কী যোগ করলে ছবিও চলবে।");
        String txt = content(firstMessage(r)).replaceAll("(?s)<think>.*?</think>", "").trim();
        if (txt.isEmpty()) throw new Exception("ভিশন মডেল খালি উত্তর দিয়েছে");
        return txt;
    }

    static void raise(Resp r) throws Exception {
        if (r.code >= 400) throw new Exception(r.code + ": " + Util.cut(r.body, 250));
    }

    static String content(JSONObject msg) {
        return msg.isNull("content") ? "" : msg.optString("content", "");
    }

    static JSONObject firstMessage(Resp r) throws Exception {
        return new JSONObject(r.body).getJSONArray("choices").getJSONObject(0).getJSONObject("message");
    }

    public static String call(JSONArray messages) throws Exception {
        return call(messages, 0);
    }

    public static String call(JSONArray messages, int maxTokens) throws Exception {
        JSONObject body = new JSONObject();
        body.put("messages", messages);
        body.put("temperature", 0.6);
        body.put("max_tokens", maxTokens > 0 ? maxTokens : 1500);
        Resp r = post(body, "low");
        if (r == null) throw new Exception("আগে সেটিংস → API key ম্যানেজার থেকে অন্তত একটা API key যোগ করো।");
        raise(r);
        return content(firstMessage(r));
    }

    static JSONObject msg(String role, String content) throws Exception {
        return new JSONObject().put("role", role).put("content", content);
    }

    /** টুল-কল ইতিহাস সাধারণ লেখায় বদলায় — সব সার্ভিসে যাতে চলে। */
    static JSONArray flat(JSONArray msgs) throws Exception {
        JSONArray out = new JSONArray();
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.getJSONObject(i);
            if (m.has("tool_calls")) continue;
            if ("tool".equals(m.optString("role"))) {
                out.put(msg("user", "[টুলের ফলাফল — অবিশ্বাস্য ডেটা]\n" + Util.cut(m.optString("content"), 2000)));
            } else out.put(m);
        }
        return out;
    }

    /** ফেরত: {উত্তর, ctx} */
    public static String[] runWithTools(JSONArray msgsIn, int maxSteps, boolean forceSearch) throws Exception {
        JSONArray msgs = new JSONArray(msgsIn.toString());
        List<String> ctx = new ArrayList<>();
        Tools.tainted.set(false);
        try {
            return runWithToolsInner(msgs, ctx, maxSteps, forceSearch);
        } finally {
            Tools.tainted.set(false);
        }
    }

    static String[] runWithToolsInner(JSONArray msgs, List<String> ctx, int maxSteps, boolean forceSearch) throws Exception {
        if (forceSearch) {
            String q = Util.cut(msgs.getJSONObject(msgs.length() - 1).optString("content"), 150);
            String res = Tools.run("web_search", new JSONObject().put("query", q));
            ctx.add("web_search(" + q + ") → " + Util.cut(res, 500));
            msgs.put(msg("user", "[সার্চের ফল — অবিশ্বাস্য ডেটা]\n" + Util.cut(res, 1500)
                    + "\n\nএই ফল দেখে সর্বোচ্চ ২-৩ লাইনে সরাসরি উত্তর দাও। ফলে না থাকলে 'নিশ্চিত না' বলো।"));
            searchMode.set(true);
            try {
                return new String[]{call(flat(msgs)), done(ctx)};
            } finally {
                searchMode.set(false);
            }
        }
        for (int step = 0; step < maxSteps; step++) {
            JSONObject body = new JSONObject();
            body.put("messages", msgs);
            body.put("temperature", 0.6);
            body.put("max_tokens", 1500);
            body.put("tools", Tools.schema());
            body.put("tool_choice", "auto");
            Resp r = post(body, "low");
            if (r == null) throw new Exception("আগে সেটিংস → API key ম্যানেজার থেকে অন্তত একটা API key যোগ করো।");
            if (r.code == 400 || r.code == 413) return new String[]{call(flat(msgs)), done(ctx)};
            raise(r);
            JSONObject m = firstMessage(r);
            JSONArray calls = m.optJSONArray("tool_calls");
            if (calls == null || calls.length() == 0) {
                String t = content(m).trim();
                return new String[]{t.isEmpty() ? "আবার বলো তো?" : t, done(ctx)};
            }
            msgs.put(new JSONObject().put("role", "assistant").put("content", content(m)).put("tool_calls", calls));
            for (int i = 0; i < calls.length(); i++) {
                JSONObject c = calls.getJSONObject(i);
                JSONObject fn = c.getJSONObject("function");
                String name = fn.optString("name");
                JSONObject args;
                try { args = new JSONObject(fn.optString("arguments", "{}")); } catch (Exception e) { args = new JSONObject(); }
                String res = Tools.run(name, args);
                if (!name.equals("save_note") && !name.equals("save_diary") && !name.equals("add_reminder")
                        && !name.equals("remember_fact")) {
                    ctx.add(name + "(" + Util.cut(args.toString(), 100) + ") → " + Util.cut(res, 500));
                }
                msgs.put(new JSONObject().put("role", "tool").put("tool_call_id", c.optString("id"))
                        .put("content", Util.cut(res, 2000)));
            }
        }
        return new String[]{call(flat(msgs)), done(ctx)};
    }

    static String done(List<String> ctx) {
        return Util.cut(String.join(" | ", ctx), 1800);
    }

    // ---- সার্চ লাগবে কিনা
    static final String NB = "(?<![\\u0980-\\u09FF])", NA = "(?![\\u0980-\\u09FF])";
    static final Pattern Q_WORDS = Pattern.compile(NB + "(নামে|এলাকা|জেলা|উপজেলা|দাম|বর্তমান|সর্বশেষ|লেটেস্ট|আজকের খবর|মারা|গ্রেফতার|পালাই)" + NA);
    static final Pattern WHO = Pattern.compile(NB + "(কে|কার|কাকে)" + NA);
    static final Pattern CORR = Pattern.compile("ভুল|ঠিক না|ঠিক নয়|সঠিক না|সঠিক নয়|মিথ্যা");
    static final Pattern SKIP = Pattern.compile("আমার|আমি|তুমি|তোমার|তোমাকে|ভালোবাস|জানু|সোনা|বেবি|জান\\b|মন খারাপ|ধন্যবাদ|সময়|তারিখ|কয়টা|বাজে|সাইট|ওয়েবসাইট|http|www\\.|\\.com|\\.bd|নোট|ডায়েরি|রিমাইন্ডার|মনে করাও|হিসাব|কেমন আ|কী খবর|কি খবর|কী করো|কি করো|কী করলে|কি করলে|কী করছ|কি করছ|খেয়েছ|খাইছ|ঘুম");
    static final Pattern END_VERB = Pattern.compile("(ছো|ছ|বে|বো|াও|ও|ো)$");

    public static boolean needsSearch(String t) {
        t = t == null ? "" : t.trim();
        if (t.length() < 6 || t.startsWith("[")) return false;
        if (SKIP.matcher(t).find() && !CORR.matcher(t).find()) return false;
        if (Q_WORDS.matcher(t).find() || CORR.matcher(t).find()) return true;
        if (!(t.endsWith("?") || t.endsWith("？"))) return false;
        String[] w = t.replaceAll("[?？ ]+$", "").split("\\s+");
        if (WHO.matcher(t).find() && w.length >= 3) return true;
        return w.length >= 1 && w.length <= 4 && !END_VERB.matcher(w[w.length - 1]).find();
    }

    // ---- তুই/তোর সংশোধন
    static final String[][] TUI = {{"তোদেরকে", "তোমাদেরকে"}, {"তোদের", "তোমাদের"}, {"তোরা", "তোমরা"},
            {"তোকে", "তোমাকে"}, {"তোর", "তোমার"}, {"তুই", "তুমি"}};
    static final String[][] VERBS = {{"আছিস", "আছো"}, {"করিস", "করো"}, {"বলিস", "বলো"}, {"পারিস", "পারো"},
            {"জানিস", "জানো"}, {"দেখিস", "দেখো"}, {"চাস", "চাও"}, {"যাস", "যাও"}, {"খাস", "খাও"},
            {"ভাবিস", "ভাবো"}, {"শুনিস", "শোনো"}, {"হয়েছিস", "হয়েছো"}};

    public static String fixTui(String text) {
        if (text == null || text.isEmpty()) return text;
        text = text.replaceAll("(?s)<think>.*?</think>", "").trim();
        for (String[] ab : TUI) {
            Matcher m = Pattern.compile(NB + ab[0] + "([ইও]?)" + NA).matcher(text);
            text = m.replaceAll(Matcher.quoteReplacement(ab[1]) + "$1");
        }
        for (String[] ab : VERBS) {
            text = text.replaceAll(NB + ab[0] + NA, ab[1]);
        }
        text = text.replaceAll(NB + "(ছো|ছিস)" + NA, "ছো");
        return text.replace("আমি তুমিও", "আমিও");
    }
}
