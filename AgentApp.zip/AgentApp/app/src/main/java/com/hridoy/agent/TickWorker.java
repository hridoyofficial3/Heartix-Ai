package com.hridoy.agent;

import android.content.Context;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.List;

/** প্রতি ~১৫ মিনিটে ব্যাকগ্রাউন্ডে চলে: সকালের গ্রিটিং, অটো-ডায়েরি, সাপ্তাহিক রিপোর্ট ইত্যাদি। */
public class TickWorker extends Worker {
    public TickWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        try {
            Context c = getApplicationContext();
            Boot.init(c);
            List<String> sent = Sched.tick();
            for (String m : sent) Alarms.notify(c, Brain.charName(), m);
        } catch (Throwable ignored) {
        }
        return Result.success();
    }
}
