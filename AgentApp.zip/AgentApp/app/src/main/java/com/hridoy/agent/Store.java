package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/** অ্যাপের ভেতরের ফাইল-স্টোর (getFilesDir)। সব ডেটা ফোনেই থাকে। */
public class Store {
    public static File dir = new File(".");
    public static String promptText = "";

    public static synchronized String read(String name, String def) {
        try {
            return new String(Files.readAllBytes(new File(dir, name).toPath()), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return def;
        }
    }

    public static synchronized void write(String name, String s) {
        try {
            Files.write(new File(dir, name).toPath(), s.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    public static synchronized byte[] readBytes(String name) {
        try {
            return Files.readAllBytes(new File(dir, name).toPath());
        } catch (Exception e) {
            return null;
        }
    }

    public static synchronized void writeBytes(String name, byte[] b) {
        try {
            Files.write(new File(dir, name).toPath(), b);
        } catch (Exception ignored) {
        }
    }

    public static synchronized void append(String name, String s) {
        try {
            Files.write(new File(dir, name).toPath(), s.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
        }
    }

    /** ফাইল max-এর বেশি হলে শেষ keep বাইট রেখে বাকিটা ফেলে (লগ ফুলে না ওঠার জন্য)। */
    public static synchronized void trim(String name, int max, int keep) {
        try {
            File f = new File(dir, name);
            if (f.length() <= max) return;
            byte[] b = Files.readAllBytes(f.toPath());
            int from = b.length - keep;
            while (from < b.length && (b[from] & 0xC0) == 0x80) from++;     // UTF-8 অক্ষরের মাঝখানে কাটবে না
            Files.write(f.toPath(), java.util.Arrays.copyOfRange(b, from, b.length));
        } catch (Exception ignored) {
        }
    }

    public static boolean exists(String name) {
        return new File(dir, name).exists();
    }

    public static List<String> lines(String name) {
        List<String> out = new ArrayList<>();
        for (String l : read(name, "").split("\n")) {
            if (!l.trim().isEmpty()) out.add(l);
        }
        return out;
    }

    public static void writeLines(String name, List<String> ls) {
        StringBuilder sb = new StringBuilder();
        for (String l : ls) sb.append(l).append("\n");
        write(name, sb.toString());
    }

    public static JSONArray arr(String name) {
        try {
            return new JSONArray(read(name, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static JSONObject obj(String name) {
        try {
            return new JSONObject(read(name, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static void save(String name, Object json) {
        write(name, json.toString());
    }

    // ---- সেটিংস (settings.json): নাম ও API কী
    public static synchronized String setting(String key) {
        return obj("settings.json").optString(key, "");
    }

    public static synchronized void setSetting(String key, String value) {
        JSONObject o = obj("settings.json");
        try {
            o.put(key, value);
        } catch (Exception ignored) {
        }
        save("settings.json", o);
    }
}
