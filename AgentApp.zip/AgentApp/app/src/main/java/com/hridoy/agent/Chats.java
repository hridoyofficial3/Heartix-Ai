package com.hridoy.agent;

import org.json.JSONArray;
import org.json.JSONObject;

/** একাধিক চ্যাট সেশন (সাইডবারের "চ্যাট" তালিকা)। প্রতিটা সেশন আলাদা ফাইলে। */
public class Chats {
    static final Object L = new Object();
    static long active = 0;
    static JSONArray list = new JSONArray();     // [{id,title,ts}]
    static JSONArray msgs = new JSONArray();     // সক্রিয় চ্যাটের বার্তা [{id,role,text,ts}]
    static boolean loaded = false;

    public static volatile boolean typing = false;
    public static volatile long typingSid = 0;
    public static volatile long seen = 0;       // UI শেষ কখন বার্তা নিয়েছে (ms)

    static String file(long sid) {
        return "chat_" + sid + ".json";
    }

    static long now() {
        return System.currentTimeMillis();
    }

    static JSONObject meta(long sid) {
        for (int i = 0; i < list.length(); i++) {
            JSONObject m = list.optJSONObject(i);
            if (m != null && m.optLong("id") == sid) return m;
        }
        return null;
    }

    static void saveIdx() {
        try {
            Store.save("sessions.json", new JSONObject().put("active", active).put("list", list));
        } catch (Exception ignored) {
        }
    }

    public static void init() {
        synchronized (L) {
            JSONObject d = Store.obj("sessions.json");
            list = d.optJSONArray("list") == null ? new JSONArray() : d.optJSONArray("list");
            active = d.optLong("active", 0);
            if (list.length() == 0) createLocked();
            else if (meta(active) == null) active = list.optJSONObject(0).optLong("id");
            msgs = Store.arr(file(active));
            loaded = true;
        }
    }

    static void ensure() {
        if (!loaded) init();
    }

    static long createLocked() {
        long sid = now();
        try {
            JSONArray nl = new JSONArray().put(new JSONObject().put("id", sid).put("title", "").put("ts", sid / 1000));
            for (int i = 0; i < list.length(); i++) nl.put(list.get(i));
            list = nl;
        } catch (Exception ignored) {
        }
        active = sid;
        msgs = new JSONArray();
        Store.save(file(sid), msgs);
        prune();
        saveIdx();
        return sid;
    }

    static void prune() {            // খালি পুরোনো চ্যাট বাদ
        JSONArray keep = new JSONArray();
        for (int i = 0; i < list.length(); i++) {
            JSONObject m = list.optJSONObject(i);
            if (m == null) continue;
            if (m.optString("title").isEmpty() && m.optLong("id") != active) {
                new java.io.File(Store.dir, file(m.optLong("id"))).delete();
            } else keep.put(m);
        }
        list = keep;
    }

    public static long active() {
        synchronized (L) { ensure(); return active; }
    }

    public static JSONObject push(String role, String text) {
        return push(role, text, 0);
    }

    public static JSONObject push(String role, String text, long sid) {
        synchronized (L) {
            ensure();
            if (sid == 0 || meta(sid) == null) sid = active;
            JSONArray ms = sid == active ? msgs : Store.arr(file(sid));
            JSONObject m = new JSONObject();
            try {
                JSONObject last = ms.length() > 0 ? ms.optJSONObject(ms.length() - 1) : null;
                m.put("id", last == null ? 1 : last.optInt("id") + 1).put("role", role).put("text", text).put("ts", now() / 1000);
                ms.put(m);
                while (ms.length() > 400) ms.remove(0);
                Store.save(file(sid), ms);
                JSONObject me = meta(sid);
                me.put("ts", now() / 1000);
                if (me.optString("title").isEmpty()) me.put("title", Util.cut(text.trim().replaceAll("\\s+", " "), 48));
                saveIdx();
            } catch (Exception ignored) {
            }
            return m;
        }
    }

    public static JSONObject since(int after, long sid) throws Exception {
        synchronized (L) {
            ensure();
            boolean t = typing && typingSid == active;
            JSONArray out = new JSONArray();
            if (sid != active) {
                for (int i = 0; i < msgs.length(); i++) out.put(msgs.get(i));
                return new JSONObject().put("reset", true).put("sid", active).put("messages", out).put("typing", t);
            }
            for (int i = 0; i < msgs.length(); i++) {
                JSONObject m = msgs.optJSONObject(i);
                if (m != null && m.optInt("id") > after) out.put(m);
            }
            return new JSONObject().put("reset", false).put("sid", active).put("messages", out).put("typing", t);
        }
    }

    public static JSONObject sessions(String q) throws Exception {
        synchronized (L) {
            ensure();
            q = q == null ? "" : q.trim().toLowerCase();
            java.util.List<JSONObject> items = new java.util.ArrayList<>();
            for (int i = 0; i < list.length(); i++) if (list.optJSONObject(i) != null) items.add(list.optJSONObject(i));
            items.sort((a, b) -> Long.compare(b.optLong("ts"), a.optLong("ts")));
            JSONArray out = new JSONArray();
            for (JSONObject x : items) {
                if (x.optString("title").isEmpty()) continue;
                if (!q.isEmpty() && !x.optString("title").toLowerCase().contains(q)) {
                    JSONArray ms = x.optLong("id") == active ? msgs : Store.arr(file(x.optLong("id")));
                    boolean hit = false;
                    for (int i = 0; i < ms.length() && !hit; i++) {
                        JSONObject m = ms.optJSONObject(i);
                        hit = m != null && m.optString("text").toLowerCase().contains(q);
                    }
                    if (!hit) continue;
                }
                if (out.length() >= 80) break;
                out.put(new JSONObject().put("id", x.optLong("id")).put("title", x.optString("title"))
                        .put("ts", x.optLong("ts")).put("active", x.optLong("id") == active));
            }
            return new JSONObject().put("sessions", out).put("active", active);
        }
    }

    public static long newSession() {
        long sid;
        synchronized (L) {
            ensure();
            if (meta(active) != null && msgs.length() == 0) return active;
            sid = createLocked();
        }
        Brain.resetHistory(new JSONArray());
        return sid;
    }

    public static boolean open(long sid) {
        JSONArray ms;
        synchronized (L) {
            ensure();
            if (meta(sid) == null) return false;
            active = sid;
            msgs = Store.arr(file(sid));
            prune();
            saveIdx();
            ms = msgs;
        }
        Brain.resetHistory(ms);
        return true;
    }

    public static boolean rename(long sid, String title) {
        String t = title == null ? "" : Util.cut(title.trim().replaceAll("\\s+", " "), 60);
        synchronized (L) {
            ensure();
            JSONObject m = meta(sid);
            if (m == null || t.isEmpty()) return false;
            try { m.put("title", t); } catch (Exception ignored) { }
            saveIdx();
            return true;
        }
    }

    public static void delete(long sid) {
        boolean was;
        synchronized (L) {
            ensure();
            JSONObject m = meta(sid);
            if (m == null) return;
            JSONArray keep = new JSONArray();
            for (int i = 0; i < list.length(); i++) if (list.optJSONObject(i) != m) keep.put(list.opt(i));
            list = keep;
            new java.io.File(Store.dir, file(sid)).delete();
            was = sid == active;
            if (was) { active = 0; msgs = new JSONArray(); }
            saveIdx();
        }
        if (was) newSession();
    }
}
