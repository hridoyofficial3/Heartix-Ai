package com.hridoy.agent;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** পুরো স্ক্রিন একটা WebView: assets/index.html-এর ডিজাইন। পেছনের কাজ Api.java-তে। */
public class MainActivity extends Activity implements Api.Env {
    private static final int REQ_PICK = 21, REQ_AVATAR = 22;
    private static final String HOST = "appassets.androidplatform.net";

    private WebView wv;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Boot.init(this);
        Api.start();
        Api.env = this;
        applyBars(Brain.settings().optString("theme", "dark"));
        askPermissions();
        startBackgroundWork();
        buildWebView();
    }

    private void buildWebView() {
        wv = new WebView(this);
        setContentView(wv);
        WebSettings st = wv.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        warnIfOldWebView();
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadUrl("https://" + HOST + "/assets/index.html");
    }

    /** Android System WebView খুব পুরোনো হলে ডিজাইন ভাঙতে পারে — আগেই জানিয়ে দেয়। */
    private void warnIfOldWebView() {
        try {
            android.content.pm.PackageInfo pi = WebView.getCurrentWebViewPackage();
            if (pi == null) {
                toast("ফোনে Android System WebView পাওয়া যায়নি। Play Store থেকে ইনস্টল/আপডেট করো।");
                return;
            }
            int major = Integer.parseInt(pi.versionName.split("\\.")[0]);
            if (major < 90) toast("ফোনের WebView পুরোনো (v" + major + ")। Play Store থেকে 'Android System WebView' আপডেট করলে ডিজাইন ঠিক দেখাবে।");
        } catch (Exception ignored) {
        }
    }

    /** JS থেকে আসা সব /api/... ডাক। ফলাফল ফেরে window.__cb(id, ok, json) দিয়ে। */
    private class Bridge {
        @JavascriptInterface
        public void call(final int id, final String path, final String body) {
            pool.execute(() -> {
                String out;
                boolean ok = true;
                try {
                    out = Api.handle(path, body);
                } catch (Throwable e) {
                    ok = false;
                    out = e.getMessage() == null ? "সমস্যা হয়েছে" : e.getMessage();
                }
                final String o = out;
                final boolean k = ok;
                runOnUiThread(() -> {
                    if (wv != null) wv.evaluateJavascript("window.__cb(" + id + "," + k + "," + JSONObject.quote(o) + ")", null);
                });
            });
        }
    }

    // ---- Api.Env
    @Override
    public void pick(final String purpose) {
        runOnUiThread(() -> {
            boolean av = "avatar".equals(purpose);
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(av ? "image/*" : "*/*");
            startActivityForResult(Intent.createChooser(i, "বেছে নিন"), av ? REQ_AVATAR : REQ_PICK);
        });
    }

    @Override
    public void quit() {
        runOnUiThread(() -> {
            try {
                WorkManager.getInstance(this).cancelUniqueWork("tick");
            } catch (Exception ignored) {
            }
            finishAndRemoveTask();
        });
    }

    @Override
    public void notifyUser(String title, String text) {
        Alarms.notify(getApplicationContext(), title, text);
    }

    @Override
    public String download(String url, boolean audio) {
        return Links.download(getApplicationContext(), url, audio);
    }

    @Override
    public void bars(final String theme) {
        runOnUiThread(() -> applyBars(theme));
    }

    @Override
    public String saveDownload(String name, byte[] data) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(u)) {
                    os.write(data);
                }
                return "Downloads/" + name;
            }
            File dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    // ---- স্ট্যাটাস/নেভিগেশন বারের রং থিম অনুযায়ী
    private void applyBars(String theme) {
        boolean dark;
        if ("light".equals(theme)) dark = false;
        else if ("auto".equals(theme))
            dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        else dark = true;
        int bg = dark ? Color.BLACK : Color.WHITE;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        View decor = getWindow().getDecorView();
        int f = decor.getSystemUiVisibility();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        decor.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
        if (wv != null) wv.setBackgroundColor(bg);
    }

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(android.Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            need.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);
    }

    private void startBackgroundWork() {
        try {
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(TickWorker.class, 15, TimeUnit.MINUTES)
                    .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build();
            WorkManager.getInstance(this).enqueueUniquePeriodicWork("tick", ExistingPeriodicWorkPolicy.KEEP, req);
            pool.execute(Brain::rescheduleAll);
        } catch (Exception ignored) {
        }
    }

    // ---- ফাইল/ছবি বাছাইয়ের ফল
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        pool.execute(() -> {
            try {
                if (req == REQ_AVATAR) {
                    JSONObject r = Api.avatarSetBytes(squareJpeg(uri));
                    if (!r.optBoolean("ok")) toast(r.optString("err", "ছবি সেট হয়নি"));
                } else if (req == REQ_PICK) {
                    String name = displayName(uri);
                    String mime = getContentResolver().getType(uri);
                    if (mime != null && mime.startsWith("image/")) {
                        String[] img = loadImage(uri);
                        Api.sendImage(name, img[0], img[1]);
                    } else {
                        try (InputStream is = getContentResolver().openInputStream(uri)) {
                            Api.sendFile(name, Util.readAll(is, 9_000_000));
                        }
                    }
                }
            } catch (Throwable e) {
                toast("ফাইল পড়া যায়নি: " + e.getMessage());
            }
        });
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
    }

    private String displayName(Uri uri) {
        String n = "file";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) n = c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return n;
    }

    private Bitmap decode(byte[] all, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(all, 0, all.length, o);
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > maxSide) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp = BitmapFactory.decodeByteArray(all, 0, all.length, o);
        if (bmp == null) throw new Exception("ছবি পড়া যায়নি");
        try {
            ExifInterface exif = new ExifInterface(new ByteArrayInputStream(all));
            int ori = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int deg = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90
                    : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180
                    : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
            if (deg != 0) {
                Matrix m = new Matrix();
                m.postRotate(deg);
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
        } catch (Exception ignored) {
        }
        return bmp;
    }

    private byte[] readUri(Uri uri) throws Exception {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            return Util.readAll(is, 25_000_000);
        }
    }

    /** ছবি ছোট (≤১২৮০px) ও সোজা করে base64 JPEG: {b64, mime} */
    private String[] loadImage(Uri uri) throws Exception {
        Bitmap bmp = decode(readUri(uri), 1280);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        return new String[]{Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP), "image/jpeg"};
    }

    /** প্রোফাইল ছবি: মাঝখান থেকে বর্গ কেটে ২৫৬px JPEG */
    private byte[] squareJpeg(Uri uri) throws Exception {
        Bitmap b = decode(readUri(uri), 1024);
        int side = Math.min(b.getWidth(), b.getHeight());
        Bitmap sq = Bitmap.createBitmap(b, (b.getWidth() - side) / 2, (b.getHeight() - side) / 2, side, side);
        Bitmap sm = Bitmap.createScaledBitmap(sq, 256, 256, true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        sm.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        return bo.toByteArray();
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wv != null) wv.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (wv != null) wv.onPause();
    }

    @Override
    protected void onDestroy() {
        if (Api.env == this) Api.env = null;
        if (wv != null) {
            wv.destroy();
            wv = null;
        }
        super.onDestroy();
    }
}
