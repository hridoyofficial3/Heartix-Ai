package com.hridoy.agent;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class Alarms {
    static final String CHANNEL = "reminders";

    public static void schedule(Context ctx, long atMillis, String id, String text) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(ctx, ReminderReceiver.class);
            i.putExtra("id", id);
            i.putExtra("text", text);
            PendingIntent pi = PendingIntent.getBroadcast(ctx, id.hashCode(), i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long t = Math.max(atMillis, System.currentTimeMillis() + 1000);
            boolean exact = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
        } catch (Exception ignored) {
        }
    }

    public static void notify(Context ctx, String text) {
        notify(ctx, "রিমাইন্ডার", text);
    }

    public static void notify(Context ctx, String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "রিমাইন্ডার", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent open = PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(ctx, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .setVisibility(Notification.VISIBILITY_PRIVATE)       // লক স্ক্রিনে লেখা দেখাবে না
                    .setPublicVersion(new Notification.Builder(ctx, CHANNEL)
                            .setSmallIcon(R.drawable.ic_notify).setContentTitle("নতুন বার্তা").build())
                    .build();
            nm.notify((int) (System.currentTimeMillis() % Integer.MAX_VALUE), n);
        } catch (Exception ignored) {
        }
    }
}
